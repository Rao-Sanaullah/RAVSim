
import os
import os.path
from PIL import Image
import numpy as np
import shutil
import sys
from pathlib import Path


def functionA(time1, size_image, path, quality, train_data, test_data, folder_name, output_image, input_list1, input_list2, input_list3, input_list4, input_list5 ):
    while(True):
        paths = path + "/"
        os.getcwd()
        for i, filename in enumerate(os.listdir(paths)):
            if filename.lower().endswith(('.' + input_list1, '.' + input_list2,'.' + input_list3,'.' + input_list4,'.' + input_list5 )):
                os.rename(paths + filename, paths + str(i) + "." + output_image)
            else:
                continue
        
        ######################################################################
        for file in os.listdir(path):
            f_img = path + "/" + file
            img = Image.open(f_img)
            img = img.resize((size_image , size_image))
            img.save(f_img, quality = quality)
        
        ######################################################################

        train_ratio = train_data/100
        test_ratio = test_data/100

        folder_name1 = [folder_name]
        classes_dir = list(map(lambda category:  "/" + category, folder_name1))
        
        print(classes_dir)

        dataset_folder = Path(path).parent
        dataset_folder1 = str(dataset_folder)
        print(dataset_folder1)

        for cls in classes_dir:
            for name in ["/train", "/test"]:
                path_name = dataset_folder1 + name + cls
                if not os.path.isdir(path_name):
                    os.makedirs(path_name)

            # Creating partitions of the data after shuffeling
            src = dataset_folder1 + cls # Folder to copy images from

            allFileNames = os.listdir(src)
            np.random.shuffle(allFileNames)
            train_FileNames, train_FileNames, test_FileNames = np.split(np.array(allFileNames), [int(len(allFileNames)* (1 - (train_ratio))),
                                                                    int(len(allFileNames)* (1 - ( test_ratio)))])

            train_FileNames = [src+'/'+ name for name in train_FileNames.tolist()]
            test_FileNames = [src+'/' + name for name in test_FileNames.tolist()]

            stdoutOrigin = sys.stdout 
            sys.stdout = open("datasetA.txt", "w")

            print(f'Total images ({cls[1:]}):', len(allFileNames))
            print(f'Training ({cls[1:]}): ', len(train_FileNames))
            print(f'Testing ({cls[1:]}): ', len(test_FileNames))
            sys.stdout.close()
            sys.stdout=stdoutOrigin


            # Copy-pasting images
            for name in train_FileNames:
                shutil.copy(name, dataset_folder1 +'/train' + cls)

            for name in test_FileNames:
                shutil.copy(name, dataset_folder1 +'/test' + cls)


            
        return time1



def functionB(time1, size_image, path, quality, train_data, test_data, folder_name, output_image, input_list1, input_list2, input_list3, input_list4, input_list5 ):
    while(True):
        paths = path + "/"
        os.getcwd()
        for i, filename in enumerate(os.listdir(paths)):
            if filename.lower().endswith(('.' + input_list1, '.' + input_list2,'.' + input_list3,'.' + input_list4,'.' + input_list5 )):
                os.rename(paths + filename, paths + str(i) + "." + output_image)
            else:
                continue
        
        ######################################################################
        for file in os.listdir(path):
            f_img = path + "/" + file
            img = Image.open(f_img)
            img = img.resize((size_image , size_image))
            img.save(f_img, quality = quality)
        
        ######################################################################

        train_ratio = train_data/100
        test_ratio = test_data/100

        folder_name1 = [folder_name]
        classes_dir = list(map(lambda category:  "/" + category, folder_name1))
        
        print(classes_dir)
        #dataset_folder = 'D:/Code/working-SNN-Model-training/dog-cat'
        dataset_folder = Path(path).parent
        dataset_folder1 = str(dataset_folder)
        print(dataset_folder1)

        for cls in classes_dir:
            for name in ["/train", "/test"]:
                path_name = dataset_folder1 + name + cls
                if not os.path.isdir(path_name):
                    os.makedirs(path_name)

            # Creating partitions of the data after shuffeling
            src = dataset_folder1 + cls # Folder to copy images from

            allFileNames = os.listdir(src)
            np.random.shuffle(allFileNames)
            train_FileNames, train_FileNames, test_FileNames = np.split(np.array(allFileNames), [int(len(allFileNames)* (1 - (train_ratio))),
                                                                    int(len(allFileNames)* (1 - ( test_ratio)))])

            train_FileNames = [src+'/'+ name for name in train_FileNames.tolist()]
            test_FileNames = [src+'/' + name for name in test_FileNames.tolist()]

            stdoutOrigin = sys.stdout 
            sys.stdout = open("datasetB.txt", "w")

            print(f'Total images ({cls[1:]}):', len(allFileNames))
            print(f'Training ({cls[1:]}): ', len(train_FileNames))
            print(f'Testing ({cls[1:]}): ', len(test_FileNames))
            sys.stdout.close()
            sys.stdout=stdoutOrigin


            # Copy-pasting images
            for name in train_FileNames:
                shutil.copy(name, dataset_folder1 +'/train' + cls)

            for name in test_FileNames:
                shutil.copy(name, dataset_folder1 +'/test' + cls)


            
        return time1


"""path = 'D:/Code/working-SNN-Model-training/dog-cat/cats/'
functionA(60,64, path, 90, 80, 20, 'cats')"""