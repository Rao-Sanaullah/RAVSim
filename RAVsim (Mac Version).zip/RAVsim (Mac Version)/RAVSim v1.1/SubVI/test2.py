#GNU GENERAL PUBLIC LICENSE

# Copyright (C) Software Foundation, Inc. <https://fsf.org/>
# Only Author of this code is permitted to copy and distribute verbatim copies
# of this license document. Please contact for us contribution~!






from unittest import TestResult
from keras.models import Model
import numpy as np
import matplotlib.pyplot as plt
from keras_preprocessing.image import ImageDataGenerator
import os
import sys
import shutil
import random
from sklearn.model_selection import train_test_split
from keras.callbacks import ModelCheckpoint
np.random.seed(101)


def main(hidden_layer_neurons, min_firing_rat, max_firing_rate, PSC,tc, r_period, vth, vreset, tsim, noise, train_data, test_data, dt1):

    input_size =  12288      
    hidden_size = hidden_layer_neurons      

    t_ref = r_period/1000 
    t_rc = tc/1000  
    t_psc = PSC/1000     
    ########################################################

    stdoutOrigin = sys.stdout 
    sys.stdout = open("log.txt", "w")

    datagen = ImageDataGenerator(
        rescale=1. / 255,
        shear_range=0.2,
        zoom_range=0.2,
    horizontal_flip=True)
    
    x_train_iterator = datagen.flow_from_directory(train_data, class_mode='categorical',shuffle=True,seed=101,target_size=(64,64), 
    color_mode="rgb", batch_size=5500)

    x_test_iterator = datagen.flow_from_directory(test_data, class_mode='categorical',shuffle=True,seed=101,target_size=(64,64), 
    color_mode="rgb", batch_size=5500)

    x_train, one_hot_train = x_train_iterator.next()
    x_test, one_hot_test = x_test_iterator.next()

    sys.stdout.close()
    sys.stdout=stdoutOrigin

    def sample_spherical(npoints): 
        vec = np.random.randn(npoints)
        vec /= np.linalg.norm(vec)
        return vec

    def simulate_neuron(Tsim, dt, t_rc, t_ref, vrest, vth, J):
        N = int(np.round(Tsim/dt))
        Vprev = 0
        Jprev = 0
        spike_train = np.zeros(N)
        mutex = 0  
        
        for i in range(N):
            if mutex == 0:
                dvdt = 1/(t_rc) * (J[i] - Vprev)
                V = Vprev + dt * dvdt
                if V < vrest:
                    V = vrest
                elif V > vth:
                    spike_train[i] = 1
                    V = vrest
                    mutex = np.round(t_ref/dt)
                Jprev = J[i]
                Vprev = V
            else:
                mutex -= 1
        return spike_train


    alpha_vec = np.zeros(hidden_size)
    J_bias_vec = np.zeros(hidden_size)
    e_vec = np.zeros((hidden_size, input_size))
    num_input = len(x_train)

    def train():
        A_train = np.zeros((num_input, hidden_size))
        for i in range(hidden_size):

            amax = np.random.uniform(min_firing_rat ,max_firing_rate)
            xi = np.random.uniform(-0.95, 0.95) 

            alpha = (1/(1-np.exp((t_ref - 1/amax)/t_rc)) - 1)/(1-xi) 
            J_bias = 1 - xi * alpha 

            e = sample_spherical(input_size)

            alpha_vec[i] = alpha 
            J_bias_vec[i] = J_bias 
            e_vec[i] = e 

            a_x = np.zeros(num_input)

            for j in range(num_input):
                J_M = np.multiply(alpha, np.inner(e, x_train[j].reshape(input_size))) + J_bias
                if J_M > 1:
                    a_x[j] = 1/(t_ref - t_rc*np.log(1- 1/J_M))

            A_train[:,i] = a_x

        mu, sigma = 0, (noise/1000)*np.max(A_train) 
        s = np.random.normal(mu, sigma, A_train.shape)
        A_noisy = np.add(A_train, s) 

        global decoder
        decoder = np.linalg.lstsq(
            A_train.T @ A_train + 0.5 * num_input * np.square(sigma) * np.eye(hidden_size), A_train.T @ one_hot_train
        , rcond=None)[0]

        x_hat = np.dot(A_noisy, decoder)
        MSE = np.mean(np.power(one_hot_train-x_hat, 2))
        MSE = round(MSE,7)
        return(MSE)


    def PSC_filter(Tsim, dt):
        t = np.linspace(0,Tsim,int(np.round(Tsim/dt))) 
        h = np.exp(-(t-Tsim/2)/t_psc) 
        h[0:len(h)//2] = 0 
        h = (1/dt)*h/np.sum(h) 
        return h

    def test():
        num_input = len(x_test)
       

        Tsim = tsim/1000  
        dt =  dt1/1000  
        v_rest = vreset 
        v_th = vth  
        Tlen = int(np.round(Tsim/dt)) 
        
        A_test = np.zeros((num_input, Tlen, hidden_size))
        h = PSC_filter(Tsim, dt)
        t = np.linspace(0, Tsim, Tlen)
        for i, (alpha, J_bias, e) in enumerate(zip(alpha_vec, J_bias_vec, e_vec)):
            a_x = np.zeros((num_input, Tlen))

            for j in range(num_input):
                J_M = np.multiply(alpha, np.inner(e, x_test[j].reshape(input_size))) + J_bias
                Jin = J_M*np.ones(Tlen)

                spike_train = simulate_neuron(Tsim, dt, t_rc, t_ref, v_rest, v_th, Jin) 
                a_x[j] = np.convolve(spike_train, h, 'same')
                
            A_test[:,:,i] = a_x
            
                    
        accuracy_history = np.zeros(Tlen)
        
        for t_i in range(Tlen):
            x_hat_test = np.dot(A_test[:,t_i,:], decoder) 
            cnt = sum(1 for i in range(num_input) if np.argmax(x_hat_test[i]) != np.argmax(one_hot_test[i]))  
            accuracy_rate = 100 - 100*cnt/num_input 
            accuracy_history[t_i] = accuracy_rate
        
        err = np.round(100 - accuracy_history[-1])

        with plt.style.context('dark_background'):
            font = {'family'           : 'serif',
                    'size'             :  30}
        
            plt.rc('font', **font)
            plt.rc('lines', linewidth=4)
            plt.figure(figsize=(34,19))

            plt.plot(t, accuracy_history, '.-')
            plt.tick_params(axis='y', labelsize='large', which='major', pad=15)
            plt.tick_params(axis='x', labelsize='large', which='major', pad=15)
            
            plt.title(f'Accuracy of model in function of time', fontsize=55, pad=25)
            
            plt.xlabel('Time [s]', fontsize=45, labelpad=30, weight='bold')
            plt.ylabel('Accuracy on test set [%]', fontsize=45, labelpad=35, weight='bold')
            plt.grid(True)

        plt.savefig('plot.jpeg', dpi=400)
        plt.close()
        

        return(err)


    MSE = train()
    file_path = 'MSE.txt'
    if os.path.isfile(file_path):
        os.remove(file_path)
        with open('MSE.txt', 'w') as f:
            f.write(str(MSE))
    else:
        with open('MSE.txt', 'w') as f:
            f.write(str(MSE))
    err = test()
    return(err)

